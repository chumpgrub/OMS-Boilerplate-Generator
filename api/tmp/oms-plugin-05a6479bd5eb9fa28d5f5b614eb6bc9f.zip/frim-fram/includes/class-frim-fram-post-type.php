<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Frim_Fram_Post_Types {

	// Post Type Frim.
	const POST_TYPE_FRIM = 'frim';
	// Post Type Fram.
	const POST_TYPE_FRAM = 'fram';

	// Taxonomy Sauce.
	const TAXONOMY_SAUCE = 'sauce';

	/**
	 * Initiate post type and taxonomy registration hooks.
	 */
	public static function init() {
        add_action( 'init', [ __CLASS__, 'register_post_types' ], 5 );
        add_action( 'init', [ __CLASS__, 'register_taxonomies' ], 5 );
		register_activation_hook( __FILE__, [ __CLASS__, 'flush_rewrites' ] );
	}

    /**
     * Register Post Types.
     */
    public static function register_post_types() {

		if ( ! post_type_exists( Frim_Fram_Post_Types::POST_TYPE_FRIM ) ) :

			register_post_type( Frim_Fram_Post_Types::POST_TYPE_FRIM,

				// Filter to modify post type.
				apply_filters( 'register_post_type_frims',
					[
						'labels'              => [
                            'name'               => _x( 'Frims', 'Post Type General Name', 'frim-fram' ),
                            'singular_name'      => _x( 'Frim', 'Post Type Singular Name', 'frim-fram' ),
                            'add_new'            => __( 'Add New', 'frim-fram' ),
                            'add_new_item'       => __( 'Add New Frim', 'frim-fram' ),
                            'edit_item'          => __( 'Edit Frim', 'frim-fram' ),
                            'new_item'           => __( 'New Frim', 'frim-fram' ),
                            'view_item'          => __( 'View Frim', 'frim-fram' ),
                            'search_items'       => __( 'Search Frims', 'frim-fram' ),
                            'not_found'          => __( 'No Frim found', 'frim-fram' ),
                            'not_found_in_trash' => __( 'No Frim found in Trash', 'frim-fram' ),
                            'parent_item_colon'  => __( 'Parent Frim:', 'frim-fram' ),
                            'menu_name'          => __( 'Frims', 'frim-fram' ),
						],
						'hierarchical'        => TRUE,
						'description'         => '', // A short descriptive summary of what the post type is.
						'supports'            => [
							'title',
							'editor',
							'excerpt',
							'thumbnail',
						],
						'public'              => TRUE,
						'menu_icon'           => 'dashicons-heart', // For more options see: https://developer.wordpress.org/resource/dashicons/
						'show_ui'             => TRUE,
						'show_in_menu'        => TRUE,
						'menu_position'       => 20,
						'show_in_nav_menus'   => TRUE,
						'publicly_queryable'  => TRUE,
						'exclude_from_search' => FALSE,
						'has_archive'         => TRUE,
						'query_var'           => TRUE,
						'can_export'          => TRUE,
						'rewrite'             => [
							'slug'       => 'frims', // Can also be "about/team" or whatever.
							'with_front' => FALSE,
						],
						'capability_type'     => 'post',
					]
				)
			);

		endif;

		if ( ! post_type_exists( Frim_Fram_Post_Types::POST_TYPE_FRAM ) ) :

			register_post_type( Frim_Fram_Post_Types::POST_TYPE_FRAM,

				// Filter to modify post type.
				apply_filters( 'register_post_type_frams',
					[
						'labels'              => [
                            'name'               => _x( 'Frams', 'Post Type General Name', 'frim-fram' ),
                            'singular_name'      => _x( 'Fram', 'Post Type Singular Name', 'frim-fram' ),
                            'add_new'            => __( 'Add New', 'frim-fram' ),
                            'add_new_item'       => __( 'Add New Fram', 'frim-fram' ),
                            'edit_item'          => __( 'Edit Fram', 'frim-fram' ),
                            'new_item'           => __( 'New Fram', 'frim-fram' ),
                            'view_item'          => __( 'View Fram', 'frim-fram' ),
                            'search_items'       => __( 'Search Frams', 'frim-fram' ),
                            'not_found'          => __( 'No Fram found', 'frim-fram' ),
                            'not_found_in_trash' => __( 'No Fram found in Trash', 'frim-fram' ),
                            'parent_item_colon'  => __( 'Parent Fram:', 'frim-fram' ),
                            'menu_name'          => __( 'Frams', 'frim-fram' ),
						],
						'hierarchical'        => TRUE,
						'description'         => '', // A short descriptive summary of what the post type is.
						'supports'            => [
							'title',
							'editor',
							'excerpt',
							'thumbnail',
						],
						'public'              => TRUE,
						'menu_icon'           => 'dashicons-heart', // For more options see: https://developer.wordpress.org/resource/dashicons/
						'show_ui'             => TRUE,
						'show_in_menu'        => TRUE,
						'menu_position'       => 20,
						'show_in_nav_menus'   => TRUE,
						'publicly_queryable'  => TRUE,
						'exclude_from_search' => FALSE,
						'has_archive'         => TRUE,
						'query_var'           => TRUE,
						'can_export'          => TRUE,
						'rewrite'             => [
							'slug'       => 'frams', // Can also be "about/team" or whatever.
							'with_front' => FALSE,
						],
						'capability_type'     => 'post',
					]
				)
			);

		endif;

    }

    /**
     * Register Taxonomies.
     */
    public static function register_taxonomies() {

		if ( ! taxonomy_exists( Frim_Fram_Post_Types::TAXONOMY_SAUCE ) ) :

			register_taxonomy( Frim_Fram_Post_Types::TAXONOMY_SAUCE,

				// Filter to modify on which post types this taxonomy can appear.
				apply_filters( 'oms_taxonomy_objects_sauces', self::getPostTypes() ),

				// Filter to modify taxonomy.
				apply_filters( 'oms_taxonomy_args_sauces', [
					'hierarchical'      => TRUE,
					'label'             => __( 'Sauces', 'frim-fram' ),
					'labels'            => [
						'name'              => __( 'Sauces', 'frim-fram' ),
						'singular_name'     => __( 'Sauce', 'frim-fram' ),
						'menu_name'         => _x( 'Sauces', 'Admin menu name', 'frim-fram' ),
						'search_items'      => __( 'Search Sauces', 'frim-fram' ),
						'all_items'         => __( 'All Sauces', 'frim-fram' ),
						'parent_item'       => __( 'Parent Sauce', 'frim-fram' ),
						'parent_item_colon' => __( 'Parent Sauce:', 'frim-fram' ),
						'edit_item'         => __( 'Edit Sauce', 'frim-fram' ),
						'update_item'       => __( 'Update Sauce', 'frim-fram' ),
						'add_new_item'      => __( 'Add New Sauce', 'frim-fram' ),
						'new_item_name'     => __( 'New Sauce Name', 'frim-fram' ),
					],
					'show_ui'           => TRUE,
					'query_var'         => TRUE,
					'public'            => TRUE,
					'show_admin_column' => TRUE,
				] )
			);

		endif;

    }

	/**
	 * Flush the rewrites.
	 */
	public static function flush_rewrites() {
		flush_rewrite_rules();
	}

    /**
     * Get all constants in class in key/value array.
     * @return array
     */
	public static function getConstants() {
        $reflection = new ReflectionClass( __CLASS__ );
        return $reflection->getConstants();
    }

    /**
     * Get all post types from class.
     * @return array
     */
    public static function getPostTypes() {
        $consts = self::getConstants();
        if ( ! empty( $consts ) ) {
            $post_types = array_filter( $consts, function( $const ) {
                return strpos( $const,'POST_TYPE_' ) === 0;
            }, ARRAY_FILTER_USE_KEY );
            return array_values( $post_types );
        }
    }

    /**
     * Get all taxonomies from class.
     * @return array
     */
    public static function getTaxonomies() {
        $consts = self::getConstants();
        if ( ! empty( $consts ) ) {
            $taxonomies = array_filter( $consts, function( $const ) {
                return strpos( $const,'TAXONOMY_' ) === 0;
            }, ARRAY_FILTER_USE_KEY );
            return array_values( $taxonomies );
        }
    }
}

Frim_Fram_Post_Types::init();
