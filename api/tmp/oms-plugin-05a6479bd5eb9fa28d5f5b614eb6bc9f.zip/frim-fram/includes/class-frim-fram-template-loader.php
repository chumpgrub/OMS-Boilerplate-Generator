<?php

/**
 * Templating functionality for Frim Fram
 */

// Don't load directly.
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Frim_Fram_Template_Loader {

	public static function init() {
		add_filter( 'template_include', [__CLASS__, 'load_template'] );
	}

	/**
	 * Pick the correct template to include.
	 *
	 * @param  string $template Path to template
	 * @return string           Path to template
	 */
	public static function load_template( $template ) {

		$file = '';

		if ( is_singular( Frim_Fram_Post_Types::getPostTypes() ) ) {
            $file = 'single-frim-fram.php';
        } elseif ( is_post_type_archive( Frim_Fram_Post_Types::getPostTypes() ) && ! is_search() ) {
            $file = 'archive-frim-fram.php';
        }

		if ( $file ) {
            // Check theme directory for template file, first.
            $template = locate_template( [ 'frim-fram/' . $file, $file ] );

            if ( ! $template ) {
                $template = Frim_Fram::plugin_path() . '/templates/' . $file;
            }
        }

		return $template;
	}

}

Frim_Fram_Template_Loader::init();
