<?php
// Silence is Golden.
?>