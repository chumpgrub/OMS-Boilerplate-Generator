<?php

/*
Plugin Name: Birthday Surprise
Plugin URI: http://www.orbitmedia.com
Description: A brief description of the Birthday Surprise.
Version: 1.0
Author: Orbit Media Studios
Author URI: http://www.orbitmedia.com
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Birthday_Surprise
 */
class Birthday_Surprise {

	/**
     * The single instance of the class.
	 */
	protected static $_instance = NULL;

	/**
     * Main Birthday_Surprise Instance.
     *
     * @see Birthday_Surprise()
	 * @return null|\Birthday_Surprise
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }

		return self::$_instance;
	}

	/**
	 * Birthday_Surprise constructor.
	 */
	public function __construct() {
		$this->init();
		$this->includes();
		$this->init_hooks();
	}

	/**
	 * Initialize code required by plugin.
	 */
	public function init() {}

	/**
	 * Include files necessary for plugin functionality.
	 */
	public function includes() {
	    // Global functions necessary for plugin.
        require_once plugin_dir_path( __FILE__ ) . 'includes/birthday-surprise-functions.php';
        // Support for plugin-level templating.
        require_once plugin_dir_path( __FILE__ ) . 'includes/class-birthday-surprise-template-loader.php';
        // Query customization are handled here.
        require_once plugin_dir_path( __FILE__ ) . 'includes/class-birthday-surprise-query.php';
        // Post Type, Taxonomy and Term Definitions.
        require_once plugin_dir_path( __FILE__ ) . 'includes/class-birthday-surprise-post-type.php';
	}

	/**
	 * Handle all actions here.
	 */
	public function init_hooks() {
	    
        
		// Create Advanced Custom Fields options sub-page.
		add_action( 'init', [ $this, 'add_options_sub_page' ] );
		// Add WooSidebars support for custom post types.
        add_action( 'init', [ $this, 'add_woosidebars_support' ] );
        // Orbit page title filter.
		add_filter( 'orbitmedia_page_title', [ $this, 'page_title' ] );
        // Orbit header image record_id filter.
		add_filter( 'orbitmedia_header_image_record_id', [ $this, 'header_image_record_id' ] );
	}

	/**
	 * Get the plugin path.
	 *
	 * @return string
	 */
	public static function plugin_path() {
		return untrailingslashit( plugin_dir_path( __FILE__ ) );
	}



    /**
	 * Add ACF Options Sub Page to post type menus.
	 */
	public function add_options_sub_page() {
		if ( function_exists( 'acf_add_options_page' ) && Birthday_Surprise_Post_Types::getPostTypes() ) {
            foreach ( Birthday_Surprise_Post_Types::getPostTypes() as $post_type ) {
                $post_type_obj = get_post_type_object( $post_type );
                $post_type_name = ( ! is_wp_error( $post_type_obj ) ) ? sprintf( '%s ', $post_type_obj->labels->name ) : '';
                acf_add_options_sub_page( array(
                    'page_title' => __( $post_type_name . ' Settings', 'birthday-surprise' ),
                    'parent'     => 'edit.php?post_type=' . $post_type,
                    'post_id'    => $post_type,
                ) );
            }
        }
	}

    /**
     * Add WooSidebars support for custom post types.
     */
    public function add_woosidebars_support() {
        if ( class_exists( 'Woo_Sidebars' ) && Birthday_Surprise_Post_Types::getPostTypes() ) {
            foreach ( Birthday_Surprise_Post_Types::getPostTypes() as $post_type ) {
                add_post_type_support( $post_type, 'woosidebars' );
            }
        }
    }
    


	/**
	 * Returns Title value entered on CPT > Settings.
	 *
	 * @param $title
	 *
	 * @return string
	 */
	public function page_title( $title ) {
        if ( Birthday_Surprise_Post_Types::getPostTypes() ) {
            if ( is_post_type_archive( Birthday_Surprise_Post_Types::getPostTypes() ) ) {
                $title = get_field( 'title', get_queried_object()->name );
                return ( $title ) ? sprintf( '<h1>%s</h1>', $title ) : $title;
            }
        }
		return $title;
	}

	/**
	 * Returns CPT slug so that header values can be pulled from the CPT >
	 * Settings options page.
	 *
	 * @param $record_id
	 *
	 * @return string|integer $record_id Either Post ID or CPT slug.
	 */
	public function header_image_record_id( $record_id ) {
        if ( Birthday_Surprise_Post_Types::getPostTypes() ) {
            if ( is_post_type_archive( Birthday_Surprise_Post_Types::getPostTypes() ) ) {
                return get_queried_object()->name;
            }
        }
		return $record_id;
	}
}

/**
 * Main instance of Birthday_Surprise.
 *
 * Returns the main instance of Birthday_Surprise to prevent the need to use
 * globals.
 *
 * @return null|Birthday_Surprise
 * @author Orbit Media Studios <wordpress@orbitmedia.com>
 */
function Birthday_Surprise() {
	return Birthday_Surprise::instance();
}

add_action( 'plugins_loaded', 'Birthday_Surprise' );
