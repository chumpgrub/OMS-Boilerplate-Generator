<?php

/**
 * Templating functionality for Birthday Surprise
 */

// Don't load directly.
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Birthday_Surprise_Template_Loader {

	public static function init() {
		add_filter( 'template_include', [__CLASS__, 'load_template'] );
	}

	/**
	 * Pick the correct template to include.
	 *
	 * @param  string $template Path to template
	 * @return string           Path to template
	 */
	public static function load_template( $template ) {

		$file = '';

		if ( is_singular( Birthday_Surprise_Post_Types::getPostTypes() ) ) {
            $file = 'single-birthday-surprise.php';
        } elseif ( is_post_type_archive( Birthday_Surprise_Post_Types::getPostTypes() ) && ! is_search() ) {
            $file = 'archive-birthday-surprise.php';
        }

		if ( $file ) {
            // Check theme directory for template file, first.
            $template = locate_template( [ 'birthday-surprise/' . $file, $file ] );

            if ( ! $template ) {
                $template = Birthday_Surprise::plugin_path() . '/templates/' . $file;
            }
        }

		return $template;
	}

}

Birthday_Surprise_Template_Loader::init();
