<?php

/**
 * Get template part.
 *
 * @param mixed $slug
 * @param string $name (default: '')
 */
function birthday_surprise_get_template_part( $slug, $name = '' ) {

	$template = '';

	// Look in yourtheme/birthday-surprise/slug-name.php
	if ( $name ) {
        $template = locate_template( array( "birthday-surprise/{$slug}-{$name}.php" ) );
    }

	// Look in yourthme/birthday-surprise/slug.php
	if ( ( ! $template && ! $name ) && file_exists( get_stylesheet_directory() . "/birthday-surprise/{$slug}.php" ) ) {
        $template = locate_template( array( "birthday-surprise/{$slug}.php" ) );
    }

	// Get default slug-name.php
	if ( ! $template && $name && file_exists( Birthday_Surprise::plugin_path() . "/templates/{$slug}-{$name}.php" ) ) {
        $template = Birthday_Surprise::plugin_path() . "/templates/{$slug}-{$name}.php";
    }

	// Get default slug.php
	if ( ( ! $template && ! $name ) && file_exists( Birthday_Surprise::plugin_path() . "/templates/{$slug}.php" ) ) {
        $template = Birthday_Surprise::plugin_path() . "/templates/{$slug}.php";
    }

	if ( $template ) {
        load_template( $template, FALSE );
    }

}


/**
 * Gets the edit link for Birthday Surprise.
 *
 * @param int $record_id ID of particular Birthday Surprise.
 * @return string
 */
function birthday_surprise_get_edit_link( $record_id ) {

	if ( is_user_logged_in() ) {

        // Get current user.
        $user = wp_get_current_user();

        // Roles with permission to edit content.
        $allowed_users = apply_filters( 'birthday_surprise_edit_permissions', [
            'client_admin',
            'administrator',
        ] );

        if ( ! empty( $user->roles ) ) {

            // If the current user roles intersect with the allowed users array, then proceed.
            if ( array_intersect( $allowed_users, $user->roles ) ) {

                return '
                    <div class="editLink">
                        <a target="_blank" href="' . get_edit_post_link( $record_id ) . '">Edit</a>
                    </div>
                ';
            }
        }
    }
}
