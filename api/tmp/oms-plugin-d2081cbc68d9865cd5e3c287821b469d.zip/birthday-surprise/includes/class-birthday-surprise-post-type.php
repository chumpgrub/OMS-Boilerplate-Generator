<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Birthday_Surprise_Post_Types {

	// Post Type Present.
	const POST_TYPE_PRESENT = 'present';
	// Post Type Cake.
	const POST_TYPE_CAKE = 'cake';

	// Taxonomy Stuff.
	const TAXONOMY_STUFF = 'stuff';

	/**
	 * Initiate post type and taxonomy registration hooks.
	 */
	public static function init() {
        add_action( 'init', [ __CLASS__, 'register_post_types' ], 5 );
        add_action( 'init', [ __CLASS__, 'register_taxonomies' ], 5 );
		register_activation_hook( __FILE__, [ __CLASS__, 'flush_rewrites' ] );
	}

    /**
     * Register Post Types.
     */
    public static function register_post_types() {

		if ( ! post_type_exists( Birthday_Surprise_Post_Types::POST_TYPE_PRESENT ) ) :

			register_post_type( Birthday_Surprise_Post_Types::POST_TYPE_PRESENT,

				// Filter to modify post type.
				apply_filters( 'register_post_type_presents',
					[
						'labels'              => [
                            'name'               => _x( 'Presents', 'Post Type General Name', 'birthday-surprise' ),
                            'singular_name'      => _x( 'Present', 'Post Type Singular Name', 'birthday-surprise' ),
                            'add_new'            => __( 'Add New', 'birthday-surprise' ),
                            'add_new_item'       => __( 'Add New Present', 'birthday-surprise' ),
                            'edit_item'          => __( 'Edit Present', 'birthday-surprise' ),
                            'new_item'           => __( 'New Present', 'birthday-surprise' ),
                            'view_item'          => __( 'View Present', 'birthday-surprise' ),
                            'search_items'       => __( 'Search Presents', 'birthday-surprise' ),
                            'not_found'          => __( 'No Present found', 'birthday-surprise' ),
                            'not_found_in_trash' => __( 'No Present found in Trash', 'birthday-surprise' ),
                            'parent_item_colon'  => __( 'Parent Present:', 'birthday-surprise' ),
                            'menu_name'          => __( 'Presents', 'birthday-surprise' ),
						],
						'hierarchical'        => TRUE,
						'description'         => '', // A short descriptive summary of what the post type is.
						'supports'            => [
							'title',
							'editor',
							'excerpt',
							'thumbnail',
						],
						'public'              => TRUE,
						'menu_icon'           => 'dashicons-heart', // For more options see: https://developer.wordpress.org/resource/dashicons/
						'show_ui'             => TRUE,
						'show_in_menu'        => TRUE,
						'menu_position'       => 20,
						'show_in_nav_menus'   => TRUE,
						'publicly_queryable'  => TRUE,
						'exclude_from_search' => FALSE,
						'has_archive'         => TRUE,
						'query_var'           => TRUE,
						'can_export'          => TRUE,
						'rewrite'             => [
							'slug'       => 'presents', // Can also be "about/team" or whatever.
							'with_front' => FALSE,
						],
						'capability_type'     => 'post',
					]
				)
			);

		endif;

		if ( ! post_type_exists( Birthday_Surprise_Post_Types::POST_TYPE_CAKE ) ) :

			register_post_type( Birthday_Surprise_Post_Types::POST_TYPE_CAKE,

				// Filter to modify post type.
				apply_filters( 'register_post_type_cakes',
					[
						'labels'              => [
                            'name'               => _x( 'Cakes', 'Post Type General Name', 'birthday-surprise' ),
                            'singular_name'      => _x( 'Cake', 'Post Type Singular Name', 'birthday-surprise' ),
                            'add_new'            => __( 'Add New', 'birthday-surprise' ),
                            'add_new_item'       => __( 'Add New Cake', 'birthday-surprise' ),
                            'edit_item'          => __( 'Edit Cake', 'birthday-surprise' ),
                            'new_item'           => __( 'New Cake', 'birthday-surprise' ),
                            'view_item'          => __( 'View Cake', 'birthday-surprise' ),
                            'search_items'       => __( 'Search Cakes', 'birthday-surprise' ),
                            'not_found'          => __( 'No Cake found', 'birthday-surprise' ),
                            'not_found_in_trash' => __( 'No Cake found in Trash', 'birthday-surprise' ),
                            'parent_item_colon'  => __( 'Parent Cake:', 'birthday-surprise' ),
                            'menu_name'          => __( 'Cakes', 'birthday-surprise' ),
						],
						'hierarchical'        => TRUE,
						'description'         => '', // A short descriptive summary of what the post type is.
						'supports'            => [
							'title',
							'editor',
							'excerpt',
							'thumbnail',
						],
						'public'              => TRUE,
						'menu_icon'           => 'dashicons-heart', // For more options see: https://developer.wordpress.org/resource/dashicons/
						'show_ui'             => TRUE,
						'show_in_menu'        => TRUE,
						'menu_position'       => 20,
						'show_in_nav_menus'   => TRUE,
						'publicly_queryable'  => TRUE,
						'exclude_from_search' => FALSE,
						'has_archive'         => TRUE,
						'query_var'           => TRUE,
						'can_export'          => TRUE,
						'rewrite'             => [
							'slug'       => 'cakes', // Can also be "about/team" or whatever.
							'with_front' => FALSE,
						],
						'capability_type'     => 'post',
					]
				)
			);

		endif;

    }

    /**
     * Register Taxonomies.
     */
    public static function register_taxonomies() {

		if ( ! taxonomy_exists( Birthday_Surprise_Post_Types::TAXONOMY_STUFF ) ) :

			register_taxonomy( Birthday_Surprise_Post_Types::TAXONOMY_STUFF,

				// Filter to modify on which post types this taxonomy can appear.
				apply_filters( 'oms_taxonomy_objects_stuffs', self::getPostTypes() ),

				// Filter to modify taxonomy.
				apply_filters( 'oms_taxonomy_args_stuffs', [
					'hierarchical'      => TRUE,
					'label'             => __( 'Stuffs', 'birthday-surprise' ),
					'labels'            => [
						'name'              => __( 'Stuffs', 'birthday-surprise' ),
						'singular_name'     => __( 'Stuff', 'birthday-surprise' ),
						'menu_name'         => _x( 'Stuffs', 'Admin menu name', 'birthday-surprise' ),
						'search_items'      => __( 'Search Stuffs', 'birthday-surprise' ),
						'all_items'         => __( 'All Stuffs', 'birthday-surprise' ),
						'parent_item'       => __( 'Parent Stuff', 'birthday-surprise' ),
						'parent_item_colon' => __( 'Parent Stuff:', 'birthday-surprise' ),
						'edit_item'         => __( 'Edit Stuff', 'birthday-surprise' ),
						'update_item'       => __( 'Update Stuff', 'birthday-surprise' ),
						'add_new_item'      => __( 'Add New Stuff', 'birthday-surprise' ),
						'new_item_name'     => __( 'New Stuff Name', 'birthday-surprise' ),
					],
					'show_ui'           => TRUE,
					'query_var'         => TRUE,
					'public'            => TRUE,
					'show_admin_column' => TRUE,
				] )
			);

		endif;

    }

	/**
	 * Flush the rewrites.
	 */
	public static function flush_rewrites() {
		flush_rewrite_rules();
	}

    /**
     * Get all constants in class in key/value array.
     * @return array
     */
	public static function getConstants() {
        $reflection = new ReflectionClass( __CLASS__ );
        return $reflection->getConstants();
    }

    /**
     * Get all post types from class.
     * @return array
     */
    public static function getPostTypes() {
        $consts = self::getConstants();
        if ( ! empty( $consts ) ) {
            $post_types = array_filter( $consts, function( $const ) {
                return strpos( $const,'POST_TYPE_' ) === 0;
            }, ARRAY_FILTER_USE_KEY );
            return array_values( $post_types );
        }
    }

    /**
     * Get all taxonomies from class.
     * @return array
     */
    public static function getTaxonomies() {
        $consts = self::getConstants();
        if ( ! empty( $consts ) ) {
            $taxonomies = array_filter( $consts, function( $const ) {
                return strpos( $const,'TAXONOMY_' ) === 0;
            }, ARRAY_FILTER_USE_KEY );
            return array_values( $taxonomies );
        }
    }
}

Birthday_Surprise_Post_Types::init();
