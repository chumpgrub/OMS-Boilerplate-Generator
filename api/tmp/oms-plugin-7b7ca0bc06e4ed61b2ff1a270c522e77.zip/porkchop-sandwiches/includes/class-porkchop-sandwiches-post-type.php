<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Porkchop_Sandwiches_Post_Types {

	// Post Type Sandwich.
	const POST_TYPE_SANDWICH = 'sandwich';
	// Post Type Chip.
	const POST_TYPE_CHIP = 'chip';

	// Taxonomy Category.
	const TAXONOMY_CATEGORY = 'porkchop-sandwiches_category';

	/**
	 * Initiate post type and taxonomy registration hooks.
	 */
	public static function init() {
        add_action( 'init', [ __CLASS__, 'register_post_types' ], 5 );
        add_action( 'init', [ __CLASS__, 'register_taxonomies' ], 5 );
		register_activation_hook( __FILE__, [ __CLASS__, 'flush_rewrites' ] );
	}

    /**
     * Register Post Types.
     */
    public static function register_post_types() {

		if ( ! post_type_exists( Porkchop_Sandwiches_Post_Types::POST_TYPE_SANDWICH ) ) :

			register_post_type( Porkchop_Sandwiches_Post_Types::POST_TYPE_SANDWICH,

				// Filter to modify post type.
				apply_filters( 'register_post_type_sandwiches',
					[
						'labels'              => [
                            'name'               => _x( 'Sandwiches', 'Post Type General Name', 'porkchop-sandwiches' ),
                            'singular_name'      => _x( 'Sandwich', 'Post Type Singular Name', 'porkchop-sandwiches' ),
                            'add_new'            => __( 'Add New', 'porkchop-sandwiches' ),
                            'add_new_item'       => __( 'Add New Sandwich', 'porkchop-sandwiches' ),
                            'edit_item'          => __( 'Edit Sandwich', 'porkchop-sandwiches' ),
                            'new_item'           => __( 'New Sandwich', 'porkchop-sandwiches' ),
                            'view_item'          => __( 'View Sandwich', 'porkchop-sandwiches' ),
                            'search_items'       => __( 'Search Sandwiches', 'porkchop-sandwiches' ),
                            'not_found'          => __( 'No Sandwich found', 'porkchop-sandwiches' ),
                            'not_found_in_trash' => __( 'No Sandwich found in Trash', 'porkchop-sandwiches' ),
                            'parent_item_colon'  => __( 'Parent Sandwich:', 'porkchop-sandwiches' ),
                            'menu_name'          => __( 'Sandwiches', 'porkchop-sandwiches' ),
						],
						'hierarchical'        => TRUE,
						'description'         => '', // A short descriptive summary of what the post type is.
						'supports'            => [
							'title',
							'editor',
							'excerpt',
							'thumbnail',
						],
						'public'              => TRUE,
						'menu_icon'           => 'dashicons-heart', // For more options see: https://developer.wordpress.org/resource/dashicons/
						'show_ui'             => TRUE,
						'show_in_menu'        => TRUE,
						'menu_position'       => 20,
						'show_in_nav_menus'   => TRUE,
						'publicly_queryable'  => TRUE,
						'exclude_from_search' => FALSE,
						'has_archive'         => TRUE,
						'query_var'           => TRUE,
						'can_export'          => TRUE,
						'rewrite'             => [
							'slug'       => 'sandwiches', // Can also be "about/team" or whatever.
							'with_front' => FALSE,
						],
						'capability_type'     => 'post',
					]
				)
			);

		endif;

		if ( ! post_type_exists( Porkchop_Sandwiches_Post_Types::POST_TYPE_CHIP ) ) :

			register_post_type( Porkchop_Sandwiches_Post_Types::POST_TYPE_CHIP,

				// Filter to modify post type.
				apply_filters( 'register_post_type_chips',
					[
						'labels'              => [
                            'name'               => _x( 'Chips', 'Post Type General Name', 'porkchop-sandwiches' ),
                            'singular_name'      => _x( 'Chip', 'Post Type Singular Name', 'porkchop-sandwiches' ),
                            'add_new'            => __( 'Add New', 'porkchop-sandwiches' ),
                            'add_new_item'       => __( 'Add New Chip', 'porkchop-sandwiches' ),
                            'edit_item'          => __( 'Edit Chip', 'porkchop-sandwiches' ),
                            'new_item'           => __( 'New Chip', 'porkchop-sandwiches' ),
                            'view_item'          => __( 'View Chip', 'porkchop-sandwiches' ),
                            'search_items'       => __( 'Search Chips', 'porkchop-sandwiches' ),
                            'not_found'          => __( 'No Chip found', 'porkchop-sandwiches' ),
                            'not_found_in_trash' => __( 'No Chip found in Trash', 'porkchop-sandwiches' ),
                            'parent_item_colon'  => __( 'Parent Chip:', 'porkchop-sandwiches' ),
                            'menu_name'          => __( 'Chips', 'porkchop-sandwiches' ),
						],
						'hierarchical'        => TRUE,
						'description'         => '', // A short descriptive summary of what the post type is.
						'supports'            => [
							'title',
							'editor',
							'excerpt',
							'thumbnail',
						],
						'public'              => TRUE,
						'menu_icon'           => 'dashicons-heart', // For more options see: https://developer.wordpress.org/resource/dashicons/
						'show_ui'             => TRUE,
						'show_in_menu'        => TRUE,
						'menu_position'       => 20,
						'show_in_nav_menus'   => TRUE,
						'publicly_queryable'  => TRUE,
						'exclude_from_search' => FALSE,
						'has_archive'         => TRUE,
						'query_var'           => TRUE,
						'can_export'          => TRUE,
						'rewrite'             => [
							'slug'       => 'chips', // Can also be "about/team" or whatever.
							'with_front' => FALSE,
						],
						'capability_type'     => 'post',
					]
				)
			);

		endif;

    }

    /**
     * Register Taxonomies.
     */
    public static function register_taxonomies() {

		if ( ! taxonomy_exists( Porkchop_Sandwiches_Post_Types::TAXONOMY_CATEGORY ) ) :

			register_taxonomy( Porkchop_Sandwiches_Post_Types::TAXONOMY_CATEGORY,

				// Filter to modify on which post types this taxonomy can appear.
				apply_filters( 'oms_taxonomy_objects_categories', self::getPostTypes() ),

				// Filter to modify taxonomy.
				apply_filters( 'oms_taxonomy_args_categories', [
					'hierarchical'      => TRUE,
					'label'             => __( 'Categories', 'porkchop-sandwiches' ),
					'labels'            => [
						'name'              => __( 'Categories', 'porkchop-sandwiches' ),
						'singular_name'     => __( 'Category', 'porkchop-sandwiches' ),
						'menu_name'         => _x( 'Categories', 'Admin menu name', 'porkchop-sandwiches' ),
						'search_items'      => __( 'Search Categories', 'porkchop-sandwiches' ),
						'all_items'         => __( 'All Categories', 'porkchop-sandwiches' ),
						'parent_item'       => __( 'Parent Category', 'porkchop-sandwiches' ),
						'parent_item_colon' => __( 'Parent Category:', 'porkchop-sandwiches' ),
						'edit_item'         => __( 'Edit Category', 'porkchop-sandwiches' ),
						'update_item'       => __( 'Update Category', 'porkchop-sandwiches' ),
						'add_new_item'      => __( 'Add New Category', 'porkchop-sandwiches' ),
						'new_item_name'     => __( 'New Category Name', 'porkchop-sandwiches' ),
					],
					'show_ui'           => TRUE,
					'query_var'         => TRUE,
					'public'            => TRUE,
					'show_admin_column' => TRUE,
				] )
			);

		endif;

    }

	/**
	 * Flush the rewrites.
	 */
	public static function flush_rewrites() {
		flush_rewrite_rules();
	}

    /**
     * Get all constants in class in key/value array.
     * @return array
     */
	public static function getConstants() {
        $reflection = new ReflectionClass( __CLASS__ );
        return $reflection->getConstants();
    }

    /**
     * Get all post types from class.
     * @return array
     */
    public static function getPostTypes() {
        $consts = self::getConstants();
        if ( ! empty( $consts ) ) {
            $post_types = array_filter( $consts, function( $const ) {
                return strpos( $const,'POST_TYPE_' ) === 0;
            }, ARRAY_FILTER_USE_KEY );
            return array_values( $post_types );
        }
    }

    /**
     * Get all taxonomies from class.
     * @return array
     */
    public static function getTaxonomies() {
        $consts = self::getConstants();
        if ( ! empty( $consts ) ) {
            $taxonomies = array_filter( $consts, function( $const ) {
                return strpos( $const,'TAXONOMY_' ) === 0;
            }, ARRAY_FILTER_USE_KEY );
            return array_values( $taxonomies );
        }
    }
}

Porkchop_Sandwiches_Post_Types::init();
